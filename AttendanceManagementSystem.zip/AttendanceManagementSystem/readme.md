# Attendance Management System

This project is made using Tkinter and SQLite.

To see the structure of database (demo.db) use [SQliteStudio](https://sqlitestudio.pl/)

## Setup
- Install Tkinter using pip command: ```pip insall tk```
- If using Python version lower than 2.5.0 intall SQlite using: ```pip install pysqlite3```
- Run the code.

### Login ID and Password

- For admin

    ID: SnehalSir

    password:SS

    ID: NikunjSir

    password:NV

- For student

    ID: yash

    password: yash1