from tkinter import messagebox

class Subjects:
    def subject_choose(_sem, _year, _dep):
        """choose subject according to sem and year"""
        sem_choice = _sem
        user_year = _year
        department = _dep
        """This function is to choose the subject for particular semester and year"""
        if user_year == 2 and department == 'BCA':
            if sem_choice == 'IV':
                subjects = ('Engineering Mathematics - IV', 'OS',
                            'DCN', 'JAVA',
                            'WP', 'Python Programming-II')
                return subjects
            elif sem_choice == 'III':
                subjects = ('Engineering Mathematics - III', 'COA', 'DS',
                            'DBMS', 'DCD', 'Python Programming-I')
                return subjects
            else:
                messagebox.showerror("Error 102", '"Error 102"')

        elif user_year == 2 and department == 'BTECH':
            if sem_choice == 'IV':
                subjects = ('Engineering Mathematics - IV', 'OS',
                            'DCN', 'JAVA',
                            'WP', 'Python Programming-II')
                return subjects
            elif sem_choice == 'III':
                subjects = ('Engineering Mathematics - III', 'COA', 'DS',
                            'DBMS', 'DCD', 'Python Programming-I')
                return subjects
            else:
                messagebox.showerror("Error 103", "Error 103")
